********************************************************
*************** � Business Spreadsheets ****************
*************  Investment Valuation Model **************
********************************************************

Thank you for downloading the Investment Valuation Model.

About the Trial Version
-----------------------
This model is compatible with Excel 97 or above and is fully functional for a trial period of 30 days.
The 30 day trial period starts when you first open the workbook.
If the product hasn't been registered with a registration key after the 30 day trial period, it will no longer carry out all functions but will still be able to be viewed.
Registration keys can be purchased by clicking the link provided in the trial form displayed upon opening the workbook.

Multiple Copies
---------------
You are able to make multiple copies of this model on the same computer.  It is recommended to make a copy of the model before use so that an original 'clean' copy is accessible without the need to download a new one.
You are entitled to run multiple copies of this model on multiple computers within your organisation if you have purchased and Enterprise license for this product.

Support
-------
Detailed user manuals, further information, and support for all Business Spreadsheets products can be found by following the links provided within the template.

Disclaimer
----------
THIS PRODUCT IS PROVIDED BY Business Spreadsheets ON AN "AS IS" BASIS. 
Business Spreadsheets MAKE NO REPRESENTATIONS OR WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, AS TO THE OPERATION OF THIS SOFTWARE OR THE INFORMATION, CONTENT, MATERIALS, OR SERVICES INCLUDED WITHIN IT. 
YOU EXPRESSLY AGREE THAT YOUR USE OF THIS SOFTWARE IS AT YOUR SOLE RISK. 
TO THE FULL EXTENT PERMISSIBLE BY APPLICABLE LAW, Business Spreadsheets DISCLAIM ALL WARRANTIES, EXPRESSED OR IMPLIED. 
Business Spreadsheets DO NOT WARRANT THAT THIS SOFTWARE, ITS SITE, ITS SERVERS, OR E-MAIL SENT FROM ANY OF ITS AFFILIATES ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS. 
Business Spreadsheets WILL NOT BE LIABLE FOR ANY LOSSES OF ANY KIND ARISING FROM THE USE OF THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO DIRECT, INDIRECT, INCIDENTAL, PUNITIVE, AND CONSEQUENTIAL LOSSES.