Hamlin's Financial Function Spread Sheet Addin

"Hamlin's Financial Funcions Spread Sheet Addin" is an Addin for Excel.  Excel is Copyrighted by Microsoft Corporation.

If the program is provided in zip format, unzip the file using an unzip program such as Winzip (Copyright Nico Mak Computing Inc.).  For information on ordering Winzip or obtaining limited time use of a free evaluation copy please contact Nico Mak Computing at www.winzip.com.

Packing List: (The following files make up this program)
HamlinReadme.txt (This file)
Hamlin.xla (The Excel add-in file)
Hamlin.hlp (Help file)

Installation Instructions:
General -  
In order to install the add-in file "Hamlin.xla" should be copied to the Library where the other add-in files are located and the help file "Hamlin.hlp" file should be copied to the directory where the other Excel help files are located.  Because the location of these files differs from version to version and sometimes machine to machine specific instructions to help you locate these directories are included below.

For Excel* for Windows 95* (Excel 7.0)-
Follow these steps:
If Excel is installed in the default directory on the C Drive:
copy Hamlin.xla to c:\MSOffice\Excel\Library
copy Hamlin.hlp to c:\MSOffice\Excel

For Excel 97*
copy Hamlin.xla to c:\Program Files\MSOffice\Excel\Library
copy Hamlin.hlp to c:\Program Files\MSOffice\Excel

For Excel 2000*
copy Hamlin.xla to c:\Program Files\MSOffice\Excel\Library
copy Hamlin.hlp to c:\Program Files\MSOffice\Excel

If you don't know your version or for some reason Excel* is not installed in the above directories:
Click the Windows Start button at the bottom of the screen (or on your keyboard). 
Click Find Files or Folders
Type *.xla in the "Named" box and select Find Now.
If necessary click and drag the edge of the "In Folder" box to make that column large enough so that the full path of where the files are located can be seen.
Copy Hamlin.xla in the main Library folder where other xla files are located (avoid copying into subfolders like "Analysis", "Solver" or "MSQuery" if possible)
Copy Hamlin.hlp into the parent folder to the Library folder.

After copying the files, the add-in can be activated within Excel.  Enter Excel and from the tools menu bar select addin (Tools- Addin).  Under "Addins Available" click on Hamlin and the add-in is now activated so that the functions are available.  The functions may be typed in or activated from the Function key. To test the installation, type HAMLININFO("v") in a cell.  The version of the Hamlin addin should appear.

If for some reason the Hamlin tool does not appear in the "Addins Available" selection choices then it is probably located in the wrong directory.  Try to follow the above procedures to find appropriate directory and move it there.  Alternatively, within Excel after choosing "Tools - Addin" you can select the Browse button to locate Hamlin.xla when it does not appear in the "Addins Available" selection choices.

After installation, help files on the functions should be available through the "function wizard" (f* button).  Hamlin functions are listed under Financial Functions.  If you get the message that the help function can not be found, Hamlin.hlp file is probably in the wrong directory.  You can move it to the correct directory or within Excel browse to locate it.  The contents of this help file can also be activated by clicking on it within Windows Explorer* or any other Windows menu.

Please note that worksheets using functions from Hamlin's Financial Function Spread Sheet Addin will not function on other computers unless these addins are installed on those machines as well.

Please feel Free to send comments to the author at DenHam@aol.com

* Excel, Excel 97, Excel 2000, Windows 95, Windows 97, Windows Explorer and Windows 2000 are Copyrighted by Microsoft Corporation.
Evaluation License:
Hamlin Financial Add-in is Copyright ( 1999-2000 by Denslo Hamlin.  All rights reserved.

This is not free software.  Subject to the terms below you are hereby licensed to use this software for evaluation purposes without charge for a period of thirty (30) days.  If you use this software after the thirty (30) day evaluation period, then a registration fee of US $40 is required.   Payments for registration must be sent to Denslo Hamlin, 615 Half Hollow Rd., Dix Hills, NY 11746.

Any fee you may have paid to others to obtain this evaluation version was a fee for their copying and distribution services, rather than a payment for continued use of the program.

The Evaluation Version of Hamlin Financial Add-in is provided "as is".   Denslo Hamlin makes no warranties of any kind, expressed or implied that the program is error free or that any supplied data or other program information is accurate or complete.  No representation or warranties are made as to the completeness, accuracy, or precision of this program and its functions.  Also, no representations or warranties are made that the formulas, program or methods used are suitable for any specific task.

ALL WARRANTIES (INCLUDING ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE) ARE EXPRESSLY EXCLUDED.  THIS SOFTWARE AND ALL PROGRAM FILES ARE PROVIDED "AS IS" AND THE USER MUST ASSUME THE ENTIRE RISK OF USING THIS PROGRAM.

Registered Version License (For Registered Copies Only):
Hamlin Financial Add-in is Copyright ( 1999-2000 by Denslo Hamlin.  All rights reserved.

Unless otherwise indicated in writing by Denslo Hamlin, Registered Version Licenses are single user licenses entitling a license holder to install and use the product on one home computer, one office computer and one portable computer provided that only one copy of the program is used at a time per license.

Denslo Hamlin warrants the physical diskette provided with registered versions to be free of defects in material and workmanship for a period of 90 days from date of registration.   If Denslo Hamlin  receives notification within the warranty period of defects in materials or workmanship, and such notification is determined by Denslo Hamlin to be correct, Denslo Hamlin will replace the defective diskette, or at Denslo Hamlin's option provide a cash refund.

The entire and exclusive liability and remedy for breach of this Limited Warranty shall be limited to the replacement of defective diskettes, or at the Denslo Hamlin's option, refund of registration fee, and shall not include or extend to any claim for or right to recover any other damages, including but not limited to:  loss of profits or other trading  losses incurred as a result of any decision or action taken based upon information provided, implied, or suggested by this product, loss of data, or use of this or any other software, or consequential damages or other similar claims even if Denslo Hamlin  has been specifically advised of the possibility of such damages.  In no event will liability for any damages exceed the lessor of the price paid for the license to use the software and the manufacturers suggested retail price, regardless of the form of any such claim or suit.

The Registration Version of Hamlin Financial Add-in is provided "as is".   Denslo Hamlin makes no warranties of any kind, expressed or implied that the program is error free or that any supplied data or other program information is accurate or complete.  No representation or warranties are made as to the completeness, accuracy, or precision of this program and its functions.  Also, no representations or warranties are made that the formulas, program or methods used are suitable for any specific task.

EXCEPT AS EXPRESSLY PROVIDED HEREIN ALL WARRANTIES (INCLUDING ANY WARRANTY OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE) ARE EXPRESSLY DISCLAIMED.  THIS SOFTWARE AND ALL PROGRAM FILES ARE PROVIDED "AS IS" AND THE USER MUST ASSUME THE ENTIRE RISK OF USING THIS PROGRAM.


Please note that worksheets created using functions from Hamlin's Financial Spread Sheet Addin will not function on other computers unless Hamlin's Financial Spread Sheet Addins are installed on these other computers.

