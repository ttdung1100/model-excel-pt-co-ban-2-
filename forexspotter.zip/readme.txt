THE FOREX$POTTER�  Version 1.0 Beta	
					


! Important: Analysis ToolPak and Analysis Toolpack-VBA on the Tools->Add-ins menu in Excel must both be checked in order for the game to recognize random numbers. The game will not work otherwise.
 

Contents						
						
I. Introduction						
						
II. Features						
            A.	Game Mode Features					
            B.	Real Mode Features					
            C.	Main screen 					
            D.	Alerts and Orders Screen					
            E.	DEM and JPY Terminals					
            F.	DEM and JPY Weekly Terminals					
						
III. Beginning the Game						
						
IV. Playing the Game						
            A.	Opening and Closing Positions					
            B.	Placing and Canceling Orders					
            C.	Margin Trading					
            D.	News Stories					
            E.	Game Over					
            F.	Game Objective and Rating System					
						
V. Hints and Strategy						
						
						
						
I. Introduction 						
						
About Forex$potter						
						
Except for being a collection of Excel spreadsheets, formulas, and Excel Visual Basic (VBA) code, Forex$potter is a foreign exchange (forex) spot market and dealing simulation tool. The program facilitates recording and tracking forex deals. It is intended for both professional traders and students.						
						
Forex$potter is unique mainly because it is used in a spreadsheet environment. While it is true that there are many financial simulation games around, Forex$potter can, at any given time, switch from simulated price movements and markets to real time prices as are displayed by any Reuters terminal. This means that Forex$potter can be used not only with computers connected to a Reuters terminal, but also with any personal computer with Excel!						
						
By learning and experiencing Forex$potter, individuals, who have never bought or sold securities, may learn about the decision-making process and risks associated with trading. 	
Additionally, investment professionals may be challenged by the analytical decision-making and 	
technical trading skills the game requires. Finally, users of Forex$potter can enter their own 	
real or simulated positions and watch their performance and account information under real 	
market conditions and prices. 						
						

II. Features						
						
A. Game Mode Features						
						
The Game Rates mode simulates a "real-time" forex market with constantly moving prices,
and financial news headlines, as the Trader attempts to react to the ever-changing economic model.
						
The Game allows a Trader to execute various forex transactions -- in seven different currency 
exchange rates -- during changing market conditions over a period of time. As the Game progresses, the combination of randomly generated pricing models, with varying economic scenarios and selected event news, creates a volatile forex market to challenge the Trader.  												
Through the different market situations presented by the Game, the Trader must make decisions	
regarding which currency to buy, sell, or hold, at which price, and in what amounts. The goal of the Game is to obtain the highest position, or ranking title, by executing profitable transactions.						
						
Features unique to the Game mode include:						
						
* Simulated markets and price movements						
* Simulated dealing and brokering						
* Commissions						
* Orders and cancellations.						
* Individual monthly and weekly currency pricing graphs						
* News terminal						
* News flashes						
* News Analysis						
* Technical analysis options						
* Rates alert requests						
						

B. Real Mode Features						
						
The Real mode is hardly a game. Real mode only works on computers which are connected to the 	
Reuters Terminal. In the Real mode, Traders can enter their transaction information and watch their real-time combined performance as well as individual positions' performance. Other useful information (e.g. leverage) is also calculated in the Main screen and in the Overall Status screen. 						
						
C. Main Screen						
						
The Main screen highlights important data relating to the Trader's current position and account value. Additionally, when either the prices of securities change or the positions in the Trader's account change, numerical fields are updated on the Main screen. Calculations monitored on the Main screen include:						
						
* Account Value						
* Current positions data						
* Paper and realized profits and losses						
* Paper and realized points gained or lost						
* Paper and realized profits and losses in dollars						
* Volume of total open positions						
* Volume of all deals made.						
* Current market prices						
* Margin levels 						
* Overall performance						
* Average return per deal in dollars and in points.						
* Market exposure						
* Market sentiment						
* Percentage and direction of a currency's fluctuation since opening a position.						
* And much more						
						
The Main screen is available in both Game and Real modes.						
						

D. Alerts and Orders Screen						
						
Traders often look for specific price levels before making deals or when analyzing the market.	
However, financial markets often fluctuate rapidly and inattentive Traders can sometimes miss the price level they are looking for only to regret the "golden opportunity" seconds later.
There are two possible solutions: The Trader could stare at the screen for every single rate tick or the Trader could request to be alerted at a desired price level. When using the latter option, the Alert screen shows the requested alert and calculates where the spot price is in relation to	that alert. Furthermore, a message will tell the Traders if this alert has been hit regardless of the screen they are watching at that moment.						
						
The Alerts screen is available in both Game and Real modes.						
						

E. DEM and JPY Terminals						
						
A brief look at either of these terminals is enough to see where the market is trading in relation to past price movements and which events or economic indicators have affected it the most.	The Deutsche mark and Japanese yen terminals are self explanatory as well as realistic. 						
Some of the main features of the DEM and JPY terminals are:						
						
* A chart of all price movements.						
* Most influential news screen.						
* Technical analysis options.						
* Bid/Ask spot prices.						
* Direction and time of the last price move.						
* Highest and lowest bids.						
* The opening and closing rates.						
* The number of moves since the start of the game.						
						

F. DEM and JPY Weekly Terminals						
						
These terminals are practically the same as the regular terminals except that they divide the month	into four trading weeks. The monthly chart from the normal DEM and JPY terminals is basically zoomed in to produce the weekly chart. However, these weekly charts are not weekly averages-- they simply show more subtle price fluctuations that are smoothed out in a monthly chart.						
						

III. Beginning the Game						
						
To start the market, select 'Start' listed under Forex$potter in the Menu Bar. The market will then commence so that prices will move and news flashes will appear. When prices are calculated, the Trader is unable to trade or enter data. It is, therefore, possible to pause the market operation by selecting 'Pause' from the Forex$potter Menu Bar.						
						
When a new Game begins, the Trader's account starts with a flat (zero) overall position on the 
first day of the month. There are only 11 deals that can be made throughout the game. Since each 
deal consists of two transactions, there is a maximum of 22 transactions that can be made 	
throughout the game.						
						
During any time period, the Trader may execute a trade by calling the broker. Importantly, the 
Trader is not required to execute a trade at any time (except in the event of a margin call).
When calling a broker the following five options are displayed: Open Position, Close Position,
Place Order, Cancel Order, and Hang Up. After selecting the appropriate button the Trader will be prompted for the data of his transactions or orders.						
						

IV. Playing the Game						
						
As the Game begins, the Trader is provided with an initial account equity (an amount of money placed into the Trader's account at the beginning of each game) of $100,000. All games begin with the Trader's position equal to zero, or as termed in the securities industry, a flat position. Since the forex market is open 24 hours a day around the globe, except on weekends, deals can be made at any given business day on any given time. A trading day consists of 24 price moves	and there are 24 trading days in the Forex$potter trading month.						
						
The Game mode continually tracks the changing forex market prices. Based on the information 
displayed during each time period, the Trader may elect to watch, analyze, or trade. 
By pressing the phone buttons on the main screen, on the toolbar, or by selecting 'Call Broker' from the Forex$potter menu, the Trader can buy or sell currencies at the current market prices   
displayed in the specific time period as well as to place or cancel an order. Throughout the Game, news stories and headlines may appear on the screen (provided that the Game mode option is on).						
						
A. Opening and Closing Positions						
						
The seven tradable exchange rates in Forex$potter 1.0 are: USD/DEM (Deutsche Marks per 
US Dollar), USD/JPY (Japanese Yens per US dollar), GBP/USD (US Dollars per British Pounds), 
USD/CHF (Swiss Francs per US Dollar), USD/ITL (Italian Liras per US Dollar), USD/FRF (French 
Francs per US Dollar), and GBP/DEM (Deutsche Marks per British Pound).						
						
Since there are eleven deals that can be made throughout the game, there are eleven position
openings and eleven position closings that can be made as well. To open a position, the Trader 
can either press the phone button (third from the top on the Forex$potter toolbar), select the
Call Broker' option from the Forex$potter Menu or click on any of the eleven phone icons located 
on the main screen left of each position line. In addition, two larger phone buttons are 
included on the DEM and JPY terminals. To close a position on the main screen simply click 
on the appropriate check box on the left of each position line.						
						
Traders must indicate which position number they are opening for if they do not click on one of the eleven phone buttons or check boxes on the main screen. 						
						
After selecting the appropriate position number the Trader must enter the amount, the pair of currencies, and the direction (Buy=Up, Sell=Down), of the trade. Choosing an amount which is too large may trigger a margin call. Choosing an amount which is too small may be a waste of a trade since there are only eleven of them! The importance of selecting the proper currencies and the 	
correct direction of the trade is obvious. 						
						
When the data of the positions are entered and the OK button is pressed, the Broker will offer the Trader a certain price. This spot price will depend on the spread and commission the Broker will choose to accept for that deal. The Trader can always decline a given price and try calling the Broker later. However, once a price is accepted, there is no turning back!						
						
When buying a security, the Trader enters an order to purchase the security at the Offer price. 
When selling a security, the Trader enters an order to sell the security at the Bid price. 
Traders must recognize that executing transactions involving a Bid-Ask Spread (selling at the Bid price and buying at the Offer price) creates an implied commission in addition to the few points collected by the broker.						
						
One should remember that throughout the Game, it is never required to execute a transaction.    
Rather, the Trader may decide to wait several time periods, or even several days, before
executing any transactions. By not executing any transactions, the Trader may be waiting 
for an appropriate price level to be reached, a noticeable trading pattern, a discernible market 
direction, a specific news story, or for some other random event to happen. 						
						
In the Game mode, the Trader can actually choose to rest for a number of hours (each hour equals  one price move) by selecting the 'Rest' option from the Forex$potter menu bar or by clicking on 
the second button from the top on the Forex$potter toolbar (the coffee/tea mug).						

While resting, no news or data will appear and it will not be possible to trade for as many hours as are chosen in the rest option.						
						

B. Placing and Canceling Orders						
						
Orders are a very important tool in the financial markets. They can provide a safety net for the 
prudent Trader or they can be very annoying by halting tremendous potential profits. 
To place an order means to tell your brokers at which rate they should execute a specific deal.	
As soon as that rate is reached, the transaction will be executed automatically by the brokers and a confirmation of the transaction will be sent to the Trader. 						
						
Market prices can move very rapidly in any direction and in very volatile conditions it is almost impossible to execute a trade at a specific desired rate. If the Trader has one or more open positions (i.e. the Trader is exposed to the market), the market can wipe out the entire equity in one single unexpected move. Therefore, the cautious Trader will place limits on the losses that can occur to any of the open positions on the account. These are called Stop-Loss Orders. However, orders	can be used for opening or closing positions as well as for taking profits. The particular orders strategy is entirely up to the individual Trader.						
						
An order can be canceled or changed at any given time before it is executed. An order will also be canceled if meanwhile a position has been opened at the same place (position number) the order	was assigned to. The message of cancellation will only appear once the ordered price is reached.						
						
C. Margin Trading						
						
The Forex$potter Game allows the Trader to margin positions. The use of a margin allows 
leverage to be utilized by the Trader to maximize returns. The term, "margin", is loosely defined as the actual or percentage amount of cash borrowed versus positions held in an account. Initial Margin Level Requirements are defined as the minimum amount of equity required in an account to maintain a position (or how much cash is required in an account on a percentage basis to own a position).						
						
The Minimum Maintenance Margin Requirement for a position is defined as the minimum level of 
account equity to be maintained in an account in order to continue to own a securities position, 
after the initial margin requirement has been met. (As the price of the margined securities drops lower the percentage account equity versus securities positions held in the account falls to a lower level).						
						
The Minimum Maintenance Margin Requirement for the $100,000 used in the Forex$potter Game
is 5%. A margin call (also referred to as a margin violation) occurs when a position is either 
purchased or sold with not enough equity in the account to meet the initial margin requirement, 
or when the total current market value of the account positions divided by the total account  
equity value falls below the minimum required maintenance margin level (due to a drop in the price of securities owned, or a rise in the prices of securities which are sold short).  						
						
When a margin call occurs due to price movement, the Game informs the Trader with a Margin Call 
Notification. Then the appropriate transactions to remedy the margin call are automatically executed by selling-out or buying-in the appropriate amount of currencies before the time period changes. 						
						
						
D. News Stories						
						
News stories may appear on the screen during the Game. News stories are important to the 
Game, because news directly affects the prices of the currencies being exchanged. Although some	
news stories may reoccur, they will by no means have the same effect on the market each time  
they appear. The effect on the market will depend on the current market conditions and it is up to the Trader to analyze the possible impact of each new story on each currency. 						
						
The Forex$potter market has some market "memory" so that news will be affecting the market for 
longer than just one price move! Any particular price at a particular moment reflects all the major	news stories or events. Therefore, it is useless to look for a particular equilibrium level since the Forex$potter market's equilibrium changes constantly!						
						

E. Game Over						
						
The Forex$potter Game continues until any one of the following events occur:						
						
1.  The Trader exits the Game; 						
2.  The month is over; 						
3.  The Account Equity reaches (or falls below) zero;						
4.  All eleven deals are made.						
						
In addition, the Trader may restart the game at any time by selecting the 'Restart' option in the Forex$potter menu bar.						
						

F. Game Objective and Rating System						
						
The object of Forex$potter is to buy and sell currencies as profitably as possible. 
The performance is based on a combination of realized and unrealized profits and losses accrued   
during the Game. Realized profit and loss figures are calculated based on the profits and losses 
from the currencies inventory which has been bought and sold during the Game. Unrealized profit and loss figures are calculated based on comparing the market exchange rates of the currencies currently owned by the Trader, to the original inventory cost (the original price positions were established). 						
						
As long as the Trader continues to have equity in the account and the Game has not been
terminated, the Trader should concentrate on profitably buying and selling securities positions. 
Therefore, the Trader should not concentrate on the length of the Game, but rather on executing profitable trades and achieving a high percentage rate of return in the account.						
						
The performance scale is relatively large and can be viewed at any time by selecting 
Your Position' from the Forex$potter menu. Each Trader starts as a trainee at the ISMA Center 
Fund, and can move to any position from "Head of Currency Department" to "Market Guru" or 
even get fired and be an object of scorn and jokes.						
						

V. Hints and Strategy						
						
Price changes and news events occur randomly. It is prudent to keep positions small until a
definite market direction can be discerned. When playing Forex$potter carefully survey 
potential economic conditions and news events. The Forex$potter Game attempts to simulate 
trading markets in a real-life fashion by using varying types of forex price reactions (normal or contrarian) to market events.  						
						
News may cause immediate, short-term, or long-term changes in the direction of the overall
forex market or in a specific exchange rate.  The prices of securities may either move up or down following the release of economic figures or unexpected news stories depending on the market conditions at that particular time.						
						
For example, in real life trading and investing, a dramatic rise in a price index signaling an onset of inflation which would typically cause the prices of bonds to fall (in a normal fashion), may sometimes cause the price of bonds to rise (in a contrarian fashion), because the reported number may have been less than what the market place expected (i.e., if analysts' expectations were for a higher rather than lower number)						
						
In general, news may have a dramatic immediate and lasting effect on individual exchange rates  or may have no impact at all.						
						
When learning how to play the Game, how to trade, and how news events affect situations, the 
careful Trader may choose to keep positions small.  As always, a prudent strategy is to buy
relatively low and sell relatively high, or sell relatively high and buy relatively low. 						
Market Clich�s:
						
1. Buy on the rumor, sell on the news; 						
2. Do not force transactions, be patient and wait for the appropriate price levels to be reached        before trading;						
3. If a position moves against you, cut your losses and get out of losing positions;						
						
Further Instructions and explanations will be included in later versions. Enjoy!						
						
***************************************************************************************************************						
Uri Schneider 						
e-mail: uri@myisp.co.uk or u.schneider@easynet.co.uk						
****************************************************************************************************************						
